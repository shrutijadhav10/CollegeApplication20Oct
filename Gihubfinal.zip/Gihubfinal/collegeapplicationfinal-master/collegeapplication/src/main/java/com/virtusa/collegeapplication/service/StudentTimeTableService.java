package com.virtusa.collegeapplication.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.collegeapplication.models.StudentTimeTable;

import com.virtusa.collegeapplication.repository.StudentTimeTableRepository;

@Service
public class StudentTimeTableService {
	@Autowired
    private StudentTimeTableRepository  studentTimeTableRepository;
	
	private static final Logger logger = LoggerFactory.getLogger("StudentTimeTable.class");
	 public List< StudentTimeTable> listAll() {
	        return studentTimeTableRepository.findAll();
	    }
		  public StudentTimeTable getFile(long id) {
		        return studentTimeTableRepository.findById(id)
		        		.orElseThrow(() -> new MyFileNotFoundException("File not found with id " + id));
		    }
		  
		  

		    public int savePdf(StudentTimeTable model) {
		        try {
		        	studentTimeTableRepository.save(model);
		            return 1;
		        } catch (Exception e) {
		            logger.error("ERROR", e);
		            return 0;
		        }
		    }
}
