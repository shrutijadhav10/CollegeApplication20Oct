package com.virtusa.collegeapplication.models;

public enum Department {
	IT("InformationTechnoloy"),
	MECH("Mechanical"),
	CSE("CSE");
	private final String selectDepartment;
	Department(String selectDepartment) {

		this.selectDepartment = selectDepartment;
	}

	public String getSelectDepartment() {

		return this.selectDepartment;
	}

}
