package com.virtusa.collegeapplication.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.virtusa.collegeapplication.models.UniversityTimeTable;
import com.virtusa.collegeapplication.repository.UniversityTimeTableRepository;


@Service
public class UniversityTimeTableService {
	@Autowired
    private UniversityTimeTableRepository universityTimeTableRepository;
	private static final Logger logger = LoggerFactory.getLogger("UniversityTimeTable.class");
    public List<UniversityTimeTable> listAll() {
        return universityTimeTableRepository.findAll();
    }
	  public UniversityTimeTable getFile(long id) {
	        return universityTimeTableRepository.findById(id)
	        		.orElseThrow(() -> new MyFileNotFoundException("File not found with id " + id));
	    }
	  
	  public int savePdf(UniversityTimeTable model) {
	        try {
	        	universityTimeTableRepository.save(model);
	            return 1;
	        } catch (Exception e) {
	            logger.error("ERROR", e);
	            return 0;
	        }
	    }
}
