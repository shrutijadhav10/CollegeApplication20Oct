package com.virtusa.collegeapplication.models;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="Applicant")
public class Applicant extends User{
	

	
	

	@Column(name="FirstName")
	private String firstName;
	@Column(name="LastName")
	private String lastName;
	
	@Column(name="Address")
	private String address;
	@Column(name="PhoneNo")
	private Long phoneNo;
	@Column(name="Gender")
	private String gender;
	@Column(name="State")
	private String state;
	@Column(name="City")
	private String city;
	@Column(name="Pincode")
	private int pincode;
	@Column(name="Birthdate")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate birthdate;

	@Column(name="Department",nullable=false)
@Enumerated(EnumType.STRING)
	private Department department;
	
	
	@Column(name="Course")
@Enumerated(EnumType.STRING)
	private Course course;
	@Column(name="SSCBoard")
	private String sscBoard;
	@Column(name="SSCPercentage")
	private int sscPercentage;
	@Column(name="HSCBoard")
	private String hscBoard;
	@Column(name="HSCPercentage")
	private int hscPercentage;
	@Column(name="DiplomaPercentage")
	private int diplomaPercentage;
	@Column(name="EnteranceExam")
	private String enteranceExam;
	@Column(name="EnteranceScore")
	private int enteranceScore;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(Long phoneNo) {
		this.phoneNo = phoneNo;
	}
	
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public LocalDate getBirthdate() {
		return birthdate;
	}
	public void setBirthdate(LocalDate birthdate) {
		this.birthdate = birthdate;
	}
	public Department getDepartment() {
		return department;
	}
	public void setDepartment(Department department) {
		this.department = department;
	}
	public Course getCourse() {
		return course;
	}
	public void setCourse(Course course) {
		this.course = course;
	}
	public String getSscBoard() {
		return sscBoard;
	}
	public void setSscBoard(String sscBoard) {
		this.sscBoard = sscBoard;
	}
	public int getSscPercentage() {
		return sscPercentage;
	}
	public void setSscPercentage(int sscPercentage) {
		this.sscPercentage = sscPercentage;
	}
	public String getHscBoard() {
		return hscBoard;
	}
	public void setHscBoard(String hscBoard) {
		this.hscBoard = hscBoard;
	}
	public int getHscPercentage() {
		return hscPercentage;
	}
	public void setHscPercentage(int hscPercentage) {
		this.hscPercentage = hscPercentage;
	}
	public int getDiplomaPercentage() {
		return diplomaPercentage;
	}
	public void setDiplomaPercentage(int diplomaPercentage) {
		this.diplomaPercentage = diplomaPercentage;
	}
	public String getEnteranceExam() {
		return enteranceExam;
	}
	public void setEnteranceExam(String enteranceExam) {
		this.enteranceExam = enteranceExam;
	}
	public int getEnteranceScore() {
		return enteranceScore;
	}
	public void setEnteranceScore(int enteranceScore) {
		this.enteranceScore = enteranceScore;
	}
	




    
    
    
    
    
	

}
