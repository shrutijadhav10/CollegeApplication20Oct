package com.virtusa.collegeapplication.configuration;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.virtusa.collegeapplication.filters.AlumniFilter;


@Configuration
public class FilterConfiguration {

	@Bean
	public FilterRegistrationBean<AlumniFilter> getFilter()
	{
		FilterRegistrationBean<AlumniFilter> reg=new FilterRegistrationBean<AlumniFilter>();
		AlumniFilter filter =new AlumniFilter();
		reg.setFilter(filter);
		reg.addUrlPatterns("/*");
		reg.setOrder(1);
		return reg;
	}
}
