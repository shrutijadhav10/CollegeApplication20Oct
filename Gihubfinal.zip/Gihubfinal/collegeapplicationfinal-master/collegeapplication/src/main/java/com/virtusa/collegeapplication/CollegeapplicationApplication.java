package com.virtusa.collegeapplication;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
/*import org.slf4j.Logger;
import org.slf4j.LoggerFactory;*/
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.virtusa.collegeapplication.configuration.CustomSuccessHandler;
import com.virtusa.collegeapplication.models.Alumni;
import com.virtusa.collegeapplication.models.ApplicantResult;
import com.virtusa.collegeapplication.repository.AlumniRepository;
import com.virtusa.collegeapplication.repository.ApplicantResultRepository;
import com.virtusa.collegeapplication.service.AlumniService;

@SpringBootApplication
public class CollegeapplicationApplication  {

	
	

	 private static Logger logger = (Logger) LogManager.getLogger(CollegeapplicationApplication.class) ;
	public static void main(String[] args)
	{
		SpringApplication.run(CollegeapplicationApplication.class, args);
		logger.info("Application Started");
	}

	

}
