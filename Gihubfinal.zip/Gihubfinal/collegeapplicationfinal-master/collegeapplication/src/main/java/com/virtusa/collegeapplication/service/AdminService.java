package com.virtusa.collegeapplication.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.collegeapplication.repository.AdminFacultyRepository;
import com.virtusa.collegeapplication.models.Faculty;
@Service
public class AdminService {

	
	
	 
	 @Autowired 
	private  AdminFacultyRepository adminFacultyRepository;
	 
	 public void save(Faculty faculty) {
	    	
		 adminFacultyRepository.save(faculty);
	    }
	 
	     
	    public List<Faculty> getAllFaculty()
	    {
	        List<Faculty> result = adminFacultyRepository.findAll();
	         
	        if(result.size() > 0) {
	            return result;
	        } else {
	            return new ArrayList<Faculty>();
	        }
	    }
	     
	   
	    
	    
	    
	    public Faculty findUserByEmail(String email) {
	        return adminFacultyRepository.findByEmail(email);
	       }
	   
	     
	    public void deleteEmployeeById(String id) throws Exception
	    {
	        Faculty employee = adminFacultyRepository.findByEmail(id);
	         
	        if(employee.isEnabled())
	        {
	        	adminFacultyRepository.deleteByEmail(id);
	        } else {
	            throw new Exception("No employee record exist for given id");
	        }
	    }
}
