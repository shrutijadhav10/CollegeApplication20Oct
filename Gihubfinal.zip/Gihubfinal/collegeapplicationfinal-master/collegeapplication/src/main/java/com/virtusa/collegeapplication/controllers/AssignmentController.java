package com.virtusa.collegeapplication.controllers;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;


import com.virtusa.collegeapplication.models.Applicant;
import com.virtusa.collegeapplication.models.Assignment;
import com.virtusa.collegeapplication.models.Submit;
import com.virtusa.collegeapplication.models.UniversityTimeTable;
import com.virtusa.collegeapplication.service.AssignmentService;
import com.virtusa.collegeapplication.service.SubmitService;

@Controller
public class AssignmentController {
	@Autowired
	private AssignmentService assignmentService;
	@Autowired
	private SubmitService submitService;
	 @Autowired
	   HttpSession httpSession;

	 
	 
//Student View All Faculty Uploaded Assignment----------------------------------------------------------------------------------
	  @RequestMapping(value= "/assignment/") 
	  public ModelAndView listAssignment(ModelAndView model) throws IOException {
			  
			  List<Assignment> listAss = assignmentService.listAll();
			   model.addObject("assignment", new Assignment());
			  model.addObject("listAss", listAss );
			  model.addObject("email", httpSession.getAttribute("studentEmail").toString());
			  model.setViewName("views/assignment");
			  
			  return model; 
			  }
	  
//Download Faculty Uploaded Assignment from Student -------------------------------------------------------------------------------------------
	  @GetMapping("/downloadAssignment/{id}")
	    public ResponseEntity<Resource> downloadFile( @PathVariable("id") long id) {
	        // Load file from database
		  Assignment dbFile = assignmentService.getFile(id);

	        return ResponseEntity.ok()
	                .contentType(MediaType.parseMediaType("text/plain"))
	                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + dbFile.getDivision() + "\"")
	                .body(new ByteArrayResource(dbFile.getPdf()));
	    }
	  
	  
//View the Student Assignment By Faculty-------------------------------------------------------------------------------------	  
	  
	  @RequestMapping(value = "/studentAssignmentView") 
	  public ModelAndView listStudentAssignment(ModelAndView model) throws IOException {
			  
			  List<Submit> listAss = submitService.listAll();
			   model.addObject("submit", new Submit());
			  model.addObject("listAss", listAss);
			  
			  model.setViewName("views/studentAssignmentView");
			  
			  return model; 
			  }
	  
//Download Student Assignment By Faculty ---------------------------------------------------------------------------------------------
	  @GetMapping("/downloadsubmitAssignment/{id}")
	    public ResponseEntity<Resource> downloadsubmitAssignment( @PathVariable("id") long id) {
	        // Load file from database
		Submit dbFile = submitService.getFile(id);

	        return ResponseEntity.ok()
	                .contentType(MediaType.parseMediaType("text/plain"))
	                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + "Assignment" + "\"")
	                .body(new ByteArrayResource(dbFile.getPdf()));
	    }

}
