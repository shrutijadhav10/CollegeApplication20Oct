
  package com.virtusa.collegeapplication.controllers;
  
  import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
  
  import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import
  org.springframework.ui.Model; import
  org.springframework.validation.BindingResult; import
  org.springframework.web.bind.annotation.ModelAttribute; import
  org.springframework.web.bind.annotation.PathVariable; import
  org.springframework.web.bind.annotation.RequestMapping; import
  org.springframework.web.bind.annotation.RequestMethod; import
  org.springframework.web.servlet.ModelAndView;
  
  import com.virtusa.collegeapplication.models.Alumni; import
  com.virtusa.collegeapplication.models.Applicant;
import com.virtusa.collegeapplication.models.ApplicantResult;
import com.virtusa.collegeapplication.models.Course;
import com.virtusa.collegeapplication.models.Department;
import com.virtusa.collegeapplication.models.User;
import com.virtusa.collegeapplication.models.UserRole;
import com.virtusa.collegeapplication.repository.ApplicantResultRepository;
import com.virtusa.collegeapplication.service.ApplicantResultService;
import
  com.virtusa.collegeapplication.service.ApplicantService;
import com.virtusa.collegeapplication.service.UserRoleService;
import com.virtusa.collegeapplication.service.UserService;



  
  
  
  
  
  
  @Controller 
  public class ApplicantController {
  
  
  
	  @Autowired
	    private ApplicantService applicantService;
	  @Autowired
	    private ApplicantResultService  applicantResultService;
  
		@Autowired
		private UserService userService;
		
		@Autowired
		private UserRoleService userRoleService;
		
		   @Autowired
		   HttpSession httpSession;
		 
//Display the Applicant Registration Form-----------------------------------------------------------------

	  @RequestMapping(value = "/applicantRegistration", method = RequestMethod.GET) 
	  public String applicantRegistration(Model model) { 
	      model.addAttribute("applicant", new Applicant());
	      model.addAttribute("departments",Arrays.asList(Department.values()));
	      model.addAttribute("courses",Arrays.asList(Course.values()));
	      return "views/applicant_register"; 
	      
	  }

	  
//Save the Applicant Registration Form------------------------------------------------------------------------------------
	  @RequestMapping(value= "/saveApplicant", method=RequestMethod.POST)
	  public ModelAndView applicantRegistrationSave(@Valid Applicant applicant, BindingResult bindingResult)
	  { 
		  ModelAndView model = new ModelAndView();
		  Applicant userExists =applicantService.findUserByEmail(applicant.getEmail());
		  model.addObject("departments",Arrays.asList(Department.values()));
	      model.addObject("courses",Arrays.asList(Course.values()));
		  if(userExists != null) {
	  
			  bindingResult.rejectValue("email", "error.applicant","This email already exists!"); 
			  model.addObject("msg", "User has been  already  registered!");
			  model.setViewName("views/applicant_register"); 
			  }
	  
		  if(bindingResult.hasErrors())
		  {
			  model.setViewName("views/applicant_register"); 
		  }
		  else 
		  { 
			  	applicant.setPassword(new BCryptPasswordEncoder().encode(applicant.getPassword()));
			  	applicant.setEnabled(true);
			  	applicantService.save(applicant);
			  	User user=userService.getUserByEmail(applicant.getEmail());
		          UserRole userRole=new UserRole();
		          userRole.setRole("ROLE_APPLICANT");
		          userRole.setUser(user);
		          userRoleService.save(userRole);
		          ApplicantResult applicantResult=new ApplicantResult();
		          applicantResult.setStatus(false);
		          applicantResult.setApplicant(applicant);
		          applicantResultService.save(applicantResult);
			  	model.addObject("msg", "User has been registered successfully!"); 
			  	model.addObject("applicant", new Applicant()); 
			    model.addObject("department",Department.values());
			    model.addObject("course",Course.values());
			  	model.setViewName("views/applicant_register"); 
			  	}
	  
	  return model; 
	  }
	 
  
	  
	  

	  //View All Applicant to Admin--------------------------------------------------------------------------------------------
		
	
	  @RequestMapping("/applicantView") public String viewAllApplicant(Model model)
	  { List<Applicant> listdata = applicantService.listAll();
	  
	 List<ApplicantResult> applicantResult = applicantService.listResultAll() ;
	 
	 
	 model.addAttribute("listdata", listdata);
	 model.addAttribute("applicantResult", applicantResult);
	  
	  return "views/adminApplicant"; }
	 
	  
//Applicant Profile After Login Controller------------------------------------------------------------	  
	  
	  @RequestMapping("/applicantProfile")
		 public ModelAndView viewApplicantByEmail() {
		     ModelAndView mav = new ModelAndView("views/applicant_view");
		     Applicant applicant = applicantService.findUserByEmail(httpSession.getAttribute("applicantEmail").toString());
		    // mav.addObject("email", email);
		     mav.addObject("applicant", applicant);
		      
		     return mav;
		 }
	  
//After Login View Status by Applicant Controller-----------------------------------------------------
	 	  @RequestMapping("/applicantStatus") 
	  public ModelAndView viewApplicantStatus(Model model) 
	  {
		  ModelAndView mav = new ModelAndView("views/applicant_status");
		  
		  ApplicantResult applicantResult =applicantResultService.findByApplicant(httpSession.getAttribute("applicantEmail").toString());
		  mav.addObject("applicant",applicantResult);
		  
		  
		  return mav; 
		  
	  }
  

//Admin Applicant Controller-------------------------------------------------------------------------------------
	 	 @RequestMapping("/edit/{email}")
		 public ModelAndView applicantStatusEditPage(@PathVariable(name = "email")String email) {
		     ModelAndView mav = new ModelAndView("views/Edit_ApplicantStatus");
		     ApplicantResult applicantResult = applicantService.findApplicantByEmail(email);
		     mav.addObject("applicantResult",  applicantResult);
		      
		     return mav;
		 }
	 	 @RequestMapping(value = "/save", method = RequestMethod.POST)
		 public String saveApplicantStatus(@ModelAttribute("applicantResult") ApplicantResult applicantResult) {
	 		userService.save(applicantResult.getApplicant());
	 		applicantService.save(applicantResult.getApplicant());
	 		applicantResultService.save(applicantResult);
	 		
	 		
		     return "redirect:/applicantView";
		 }
	 
  }