package com.virtusa.collegeapplication.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.collegeapplication.models.Alumni;
import com.virtusa.collegeapplication.models.Applicant;
import com.virtusa.collegeapplication.models.ApplicantResult;
import com.virtusa.collegeapplication.repository.ApplicantRepository;
import com.virtusa.collegeapplication.repository.ApplicantResultRepository;



@Service

public class ApplicantService {

	@Autowired
    private ApplicantRepository applicantRepository;
	@Autowired
	private ApplicantResultRepository applicantResultRepository;
     
   
    public void save(Applicant applicant) {
    	applicantRepository.save(applicant);
    }
    public void saveApplicantResult(ApplicantResult applicantResult) {
    	applicantResultRepository.save(applicantResult);
    }
    
  
    public Applicant findUserByEmail(String email) {
     return applicantRepository.findByEmail(email);
    }
    public List<Applicant> listAll() {
        return applicantRepository.findAll();
    }
    public List<ApplicantResult> listResultAll() {
        return applicantResultRepository.findAll();
    }
   public ApplicantResult findApplicantByEmail(String email)
   {
	   return applicantResultRepository.findByApplicant(email);
   }
	  
   
}
