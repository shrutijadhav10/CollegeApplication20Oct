package com.virtusa.collegeapplication.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.collegeapplication.models.ApplicantResult;
import com.virtusa.collegeapplication.models.StudentResult;
import com.virtusa.collegeapplication.repository.StudentResultRepository;

@Service
public class StudentResultService {
	@Autowired
	private StudentResultRepository studentResultRepository;
	
	public StudentResult save(StudentResult studentResult)
	{
		return studentResultRepository.save(studentResult);
		
		
	}


	public StudentResult  findByStudent(String email) {
		return studentResultRepository.findByStudent(email);
	}
	public List<StudentResult> listResultAll() {
        return studentResultRepository.findAll();
    }
}
