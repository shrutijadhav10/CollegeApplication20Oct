package com.virtusa.collegeapplication.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.virtusa.collegeapplication.models.Student;

public interface StudentRepository extends JpaRepository<Student, String> {
	Student findByEmail(String email);
}
