package com.virtusa.collegeapplication.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.collegeapplication.models.Faculty;

public interface FacultyRepository extends JpaRepository<Faculty, String> {
Faculty findByEmail(String email);
}
