package com.virtusa.collegeapplication.controllers;

import java.util.Arrays;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.collegeapplication.models.Alumni;
import com.virtusa.collegeapplication.models.Applicant;
import com.virtusa.collegeapplication.models.ApplicantResult;
import com.virtusa.collegeapplication.models.Course;
import com.virtusa.collegeapplication.models.Department;
import com.virtusa.collegeapplication.models.Event;
import com.virtusa.collegeapplication.models.EventType;
import com.virtusa.collegeapplication.models.User;
import com.virtusa.collegeapplication.models.UserRole;
import com.virtusa.collegeapplication.service.ApplicantService;
import com.virtusa.collegeapplication.service.EventService;

@Controller 
public class EventController {

	 @Autowired
	    private EventService eventService;
	
	  @RequestMapping("/eventView") 
	  public String viewAllEvents(Model model) {
	  List<Event> events = eventService.listAllEvent();
	  model.addAttribute("events", events);
	  
	
	  return "views/student_event"; }
	  
	  
	   
	    
	    
}
