package com.virtusa.collegeapplication.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.collegeapplication.models.ApplicantResult;
import com.virtusa.collegeapplication.repository.ApplicantResultRepository;

@Service
public class ApplicantResultService {
	@Autowired
	private ApplicantResultRepository applicantResultRepository;
     
public ApplicantResult save(ApplicantResult applicantResult)
{
	return applicantResultRepository.save(applicantResult);
	
	
}


public ApplicantResult  findByApplicant(String email) {
	return applicantResultRepository.findByApplicant(email);
}

}
