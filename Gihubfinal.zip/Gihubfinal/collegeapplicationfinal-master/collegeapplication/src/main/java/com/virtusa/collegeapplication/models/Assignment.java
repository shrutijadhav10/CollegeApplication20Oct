
  package com.virtusa.collegeapplication.models;
  
  import javax.persistence.CascadeType; import javax.persistence.Column; import
  javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType; import
  javax.persistence.GeneratedValue; import javax.persistence.GenerationType;
  import javax.persistence.Id; import javax.persistence.Inheritance; import
  javax.persistence.InheritanceType; import javax.persistence.JoinColumn;
  import javax.persistence.Lob; import javax.persistence.ManyToOne; import
  javax.persistence.OneToOne; import javax.persistence.Table;
  
  
  
  @Entity
  

  
  @Table(name="Assignment")
  public class Assignment {
  
  @Id
  @GeneratedValue(strategy=GenerationType.AUTO)
  
  @Column(name="Id") 
  private Long id;
  
	@Column(name="Department")
	@Enumerated(EnumType.STRING)
	private Department department;
	@Column(name="Semester")
	@Enumerated(EnumType.STRING)
	private Semester semester;
  
	@Column(name="Year")
	@Enumerated(EnumType.STRING)
	private Year year;
  

  
  @Column(name="Division") 

  private String division;
  
  @Lob
  @Column(name="Pdf")
  private byte[] pdf;
  
  @ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.LAZY) 
  private Faculty faculty;





public Assignment(byte[] pdf, Faculty faculty, Department department, Year year, String division,
		Semester semester) {
	// TODO Auto-generated constructor stub
	this.pdf=pdf;
	this.department=department;
	this.year=year;
	this.division=division;
	this.faculty=faculty;
	this.semester=semester;
}



public Assignment() {
	// TODO Auto-generated constructor stub
}



public Long getId() {
	return id;
}

public void setId(Long id) {
	this.id = id;
}

public Department getDepartment() {
	return department;
}

public void setDepartment(Department department) {
	this.department = department;
}

public Semester getSemester() {
	return semester;
}

public void setSemester(Semester semester) {
	this.semester = semester;
}

public Year getYear() {
	return year;
}

public void setYear(Year year) {
	this.year = year;
}

public String getDivision() {
	return division;
}

public void setDivision(String division) {
	this.division = division;
}

public byte[] getPdf() {
	return pdf;
}

public void setPdf(byte[] pdf) {
	this.pdf = pdf;
}

public Faculty getFaculty() {
	return faculty;
}

public void setFaculty(Faculty faculty) {
	this.faculty = faculty;
}
  
  
  
  }
 