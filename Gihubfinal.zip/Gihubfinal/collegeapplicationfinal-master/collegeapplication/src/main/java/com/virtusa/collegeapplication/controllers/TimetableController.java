package com.virtusa.collegeapplication.controllers;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.collegeapplication.models.FacultyTimeTable;
import com.virtusa.collegeapplication.models.StudentTimeTable;
import com.virtusa.collegeapplication.models.UniversityTimeTable;
import com.virtusa.collegeapplication.service.FacultyTimeTableService;
import com.virtusa.collegeapplication.service.StudentTimeTableService;
import com.virtusa.collegeapplication.service.UniversityTimeTableService;

@Controller
public class TimetableController {
	@Autowired
	private UniversityTimeTableService universityTimeTableService;
	@Autowired
	private StudentTimeTableService studentTimeTableService;
	@Autowired
	private FacultyTimeTableService facultyTimeTableService;
	
	  @RequestMapping(value = "/university") public ModelAndView listStudent(ModelAndView
			  model) throws IOException {
			  
			  List<UniversityTimeTable> listStu = universityTimeTableService.listAll();
			  
			  model.addObject("listStu", listStu);
			  model.setViewName("views/university");
			  
			  return model; }
	  @GetMapping("/downloadFile/{id}")
	    public ResponseEntity<Resource> downloadFile( @PathVariable("id") long id) {
	        // Load file from database
		  UniversityTimeTable dbFile = universityTimeTableService.getFile(id);

	        return ResponseEntity.ok()
	                .contentType(MediaType.parseMediaType("text/plain"))
	                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + dbFile.getDivision() + "\"")
	                .body(new ByteArrayResource(dbFile.getPdf()));
	    }
	  @RequestMapping(value = "/studentTimetable") public ModelAndView listStudentTimetable(ModelAndView
			  model) throws IOException {
			  
			  List<StudentTimeTable> listStu = studentTimeTableService.listAll();
			  
			  model.addObject("listStu", listStu);
			  model.setViewName("views/studentTimetable");
			  
			  return model; }
	  @GetMapping("/downloadStudentFile/{id}")
	    public ResponseEntity<Resource> downloadStudentFile( @PathVariable("id") long id) {
	        // Load file from database
		  StudentTimeTable dbFile = studentTimeTableService.getFile(id);

	        return ResponseEntity.ok()
	                .contentType(MediaType.parseMediaType("text/plain"))
	                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + dbFile.getDivision() + "\"")
	                .body(new ByteArrayResource(dbFile.getPdf()));
	    }
	  
	  @RequestMapping(value = "/facultyTimetable") 
	  public ModelAndView listFacultyTimetable(ModelAndView
			  model) throws IOException {
			  
			  List<FacultyTimeTable> listStu = facultyTimeTableService.listAll();
			  
			  model.addObject("listStu", listStu);
			  model.setViewName("views/facultyTimetable");
			  
			  return model; }
}
