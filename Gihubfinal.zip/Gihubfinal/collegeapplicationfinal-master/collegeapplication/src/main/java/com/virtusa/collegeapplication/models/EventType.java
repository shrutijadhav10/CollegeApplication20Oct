package com.virtusa.collegeapplication.models;

public enum EventType {
	ANNUAL("ANNUAL"),
	MEETING("MEETING"),
	PLACEMENT("PLACEMENT"),
	RESULT("RESULT");
	private final String selectEventType;
	EventType(String selectEventType) {

		this.selectEventType =selectEventType;
	}

	public String getSelectEventType() {

		return this.selectEventType;
	}
	

}
