package com.virtusa.collegeapplication.service;

  import javax.transaction.Transactional;
  
  import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import
  org.springframework.stereotype.Service;

import com.virtusa.collegeapplication.models.Student;
import com.virtusa.collegeapplication.models.User;
import com.virtusa.collegeapplication.repository.UserRepository;
  

  
  
  @Service
  
  public class UserService {
  
  @Autowired private UserRepository userRepository;
  
  public User getUserByEmail(String email) {
  
  return userRepository.getOne(email);
  
  }
  

  public void save(User user) {
	  userRepository.save(user);
  }
  
  
  }
 