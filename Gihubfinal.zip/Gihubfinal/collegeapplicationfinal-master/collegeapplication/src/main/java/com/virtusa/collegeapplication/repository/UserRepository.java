package com.virtusa.collegeapplication.repository;

  import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.collegeapplication.models.User;
import com.virtusa.collegeapplication.models.UserRole; 

  
  
  public interface UserRepository extends JpaRepository<User, String>{

	
  
  }
 