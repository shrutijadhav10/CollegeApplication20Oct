package com.virtusa.collegeapplication.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.virtusa.collegeapplication.models.Applicant;


public interface ApplicantRepository extends JpaRepository<Applicant, Long>{
	
Applicant findByEmail(String email);

}
