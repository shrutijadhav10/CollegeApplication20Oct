package com.virtusa.collegeapplication.models;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name ="StudentResult") 
public class StudentResult {
	
	 @Id
	  @GeneratedValue(strategy=GenerationType.AUTO)
	  @Column(name="Id") 
	  private Long id;
	  @OneToOne(cascade = CascadeType.MERGE, fetch = FetchType.LAZY) 
	  private Student student;
	  @Column(name="Status")
	  private boolean status;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	  

}
