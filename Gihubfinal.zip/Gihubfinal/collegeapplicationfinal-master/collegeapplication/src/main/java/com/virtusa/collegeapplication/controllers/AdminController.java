package com.virtusa.collegeapplication.controllers;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.virtusa.collegeapplication.models.Faculty;
import com.virtusa.collegeapplication.models.FacultyTimeTable;
import com.virtusa.collegeapplication.models.Semester;
import com.virtusa.collegeapplication.models.Student;
import com.virtusa.collegeapplication.models.StudentResult;
import com.virtusa.collegeapplication.models.StudentTimeTable;
import com.virtusa.collegeapplication.models.Submit;
import com.virtusa.collegeapplication.models.UniversityTimeTable;
import com.virtusa.collegeapplication.models.User;
import com.virtusa.collegeapplication.models.UserRole;
import com.virtusa.collegeapplication.models.Year;
import com.virtusa.collegeapplication.models.Applicant;
import com.virtusa.collegeapplication.models.ApplicantResult;
import com.virtusa.collegeapplication.models.Assignment;
import com.virtusa.collegeapplication.models.Course;
import com.virtusa.collegeapplication.models.Department;
import com.virtusa.collegeapplication.models.Event;
import com.virtusa.collegeapplication.models.EventType;
import com.virtusa.collegeapplication.repository.AdminFacultyRepository;
import com.virtusa.collegeapplication.repository.ApplicantResultRepository;
import com.virtusa.collegeapplication.service.AdminService;
import com.virtusa.collegeapplication.service.ApplicantService;
import com.virtusa.collegeapplication.service.EventService;
import com.virtusa.collegeapplication.service.FacultyService;
import com.virtusa.collegeapplication.service.FacultyTimeTableService;
import com.virtusa.collegeapplication.service.StudentResultService;
import com.virtusa.collegeapplication.service.StudentService;
import com.virtusa.collegeapplication.service.StudentTimeTableService;
import com.virtusa.collegeapplication.service.SubmitService;
import com.virtusa.collegeapplication.service.TimeTableService;
import com.virtusa.collegeapplication.service.UniversityTimeTableService;
import com.virtusa.collegeapplication.service.UserRoleService;
import com.virtusa.collegeapplication.service.UserService;

@Controller
public class AdminController {
	
	

	 @Autowired
	    private ApplicantService applicantservice;
	 @Autowired
	    private ApplicantResultRepository  applicantResultRepository;
	 
	private AdminFacultyRepository adminFacultyRepository;
	 @Autowired
	    AdminService adminservice;
	 @Autowired
	    private  StudentTimeTableService studentTimeTableService;
	 @Autowired
	    private  UniversityTimeTableService universityTimeTableService;
	 @Autowired
	    private  FacultyTimeTableService facultyTimeTableService;
	 @Autowired
	    private  StudentService studentService;
	 @Autowired
	    private UserRoleService userRoleService;
	 
	 @Autowired
	    private FacultyService facultyService;
	 @Autowired
	    private StudentResultService studentResultService;
	 
	 @Autowired
	    private  UserService userService;
	
	 private static final Logger logger = (Logger) LogManager.getLogger(AdminController.class) ;
	 
	
	
	
   
    
    
  //View The Admin Page 
     @GetMapping("/adminHome")
     public String adminHome()
     {
    	 return "views/adminHome";
     }
  
    
    
	
	// Event Controller ====================================================================
	@Autowired
	private EventService eventService;
	
	  @RequestMapping(value= "/saveEvent", method=RequestMethod.POST)
	  public ModelAndView applicantRegistrationSave(@Valid Event event)
	  { 
		  ModelAndView model = new ModelAndView();
		 
		  eventService.save(event);
			  	
			  	model.addObject("msg", "Event Saved!"); 
			  	model.addObject("event", new Event()); 
			    model.addObject("events",EventType.values());
			   
			  	model.setViewName("views/events"); 
			  	
	  
	  return model; 
	  }
	 
	  @RequestMapping(value = "/showEvent", method = RequestMethod.GET) 
	  public String applicantRegistration(Model model) { 
	      model.addAttribute("event", new Event());
	      model.addAttribute("events",EventType.values());
	     
	      return "views/events"; 
	      
	  }
	  
	//Student Timetable====================================================================
	  
	  @RequestMapping(value = "/adminStudentTimetable", method = RequestMethod.GET) 
	  public String studentTimetable(Model model) { 
	    //  model.addAttribute("studentTimeTable", new StudentTimeTable());
	      model.addAttribute("departments",Arrays.asList(Department.values()));
	      model.addAttribute("semesters",Arrays.asList(Semester.values()));
	      model.addAttribute("years",Arrays.asList(Year.values()));
	      return "views/adminStudentTimeTable"; 
	      
	  }
	  
	 
	  
	  @PostMapping("/studentTimeTable")
	    public String fileUpload(@RequestParam("timetableType")String timetableType,@RequestParam("department")Department department,@RequestParam("semester")Semester semester,@RequestParam("year")Year year,@RequestParam("division")String division, @RequestParam("file") MultipartFile file,Model mv) {
	        try {
	         //   logger.info("Name= " + name);
	            byte[] image = file.getBytes();
	          StudentTimeTable model = new StudentTimeTable(timetableType,department, semester,year,division,image);
	          List<StudentTimeTable> listStu = studentTimeTableService.listAll();
			  
			  mv.addAttribute("listStu", listStu);
	            int saveImage = studentTimeTableService.savePdf(model);
	            if (saveImage == 1) {
	            	 
	            	mv.addAttribute("message", "Sucessfully Uploaded"); 
	               
	                return "redirect:/adminStudentTimetable";
	            } else {
	                return "error";
	            }
	        } catch (Exception e) {
	            logger.error("ERROR", e);
	            return "error";
	        }
	    }
	  
//University Timetable====================================================================
	  
	  @RequestMapping(value = "/adminUniversityTimetable", method = RequestMethod.GET) 
	  public String universityTimetable(Model model) { 
	    //  model.addAttribute("studentTimeTable", new StudentTimeTable());
	      model.addAttribute("departments",Arrays.asList(Department.values()));
	      model.addAttribute("semesters",Arrays.asList(Semester.values()));
	      model.addAttribute("years",Arrays.asList(Year.values()));
	      return "views/adminUniversityTimeTable"; 
	      
	  }
	  
	 
	  
	  @PostMapping("/universityTimeTable")
	    public String UniversityUpload(@RequestParam("timetableType")String timetableType,@RequestParam("department")Department department,@RequestParam("semester")Semester semester,@RequestParam("year")Year year,@RequestParam("division")String division, @RequestParam("file") MultipartFile file,Model mv) {
	        try {
	         //   logger.info("Name= " + name);
	            byte[] image = file.getBytes();
	            UniversityTimeTable model = new UniversityTimeTable(timetableType,department, semester,year,division,image);
	          
	            int saveImage = universityTimeTableService.savePdf(model);
	            if (saveImage == 1) {
	            	 
	            	mv.addAttribute("message", "Sucessfully Uploaded"); 
	               
	                return "redirect:/adminUniversityTimetable";
	            } else {
	                return "error";
	            }
	        } catch (Exception e) {
	            logger.error("ERROR", e);
	            return "error";
	        }
	    }
    
	  
//Faculty Timetable====================================================================
	  
	  @RequestMapping(value = "/adminFacultyTimetable", method = RequestMethod.GET) 
	  public String facultyTimetable(Model model) { 
	    //  model.addAttribute("studentTimeTable", new StudentTimeTable());
	      model.addAttribute("departments",Arrays.asList(Department.values()));
	      model.addAttribute("semesters",Arrays.asList(Semester.values()));
	      model.addAttribute("years",Arrays.asList(Year.values()));
	      return "views/adminFacultyTimeTable"; 
	      
	  }
	  
	 
	  
	  @PostMapping("/facultyTimeTable")
	    public String facultyUpload(@RequestParam("timetableType")String timetableType,@RequestParam("department")Department department,@RequestParam("semester")Semester semester,@RequestParam("year")Year year,@RequestParam("division")String division, @RequestParam("file") MultipartFile file,Model mv) {
	        try {
	         //   logger.info("Name= " + name);
	            byte[] image = file.getBytes();
	           FacultyTimeTable model = new FacultyTimeTable(timetableType,department, semester,year,division,image);
	            List<FacultyTimeTable> listStu = facultyTimeTableService.listAll();
			  
			  mv.addAttribute("listStu", listStu);
	            int saveImage = facultyTimeTableService.savePdf(model);
	            if (saveImage == 1) {
	            	 
	            	mv.addAttribute("message", "Sucessfully Uploaded"); 
	               
	                return "redirect:/adminFacultyTimetable";
	            } else {
	                return "error";
	            }
	        } catch (Exception e) {
	            logger.error("ERROR", e);
	            return "error";
	        }
	    }
    //Student registration----------------------------------------------------------
	  @GetMapping(value = "/studentaddlogin") 
	  public String studentlogincred(Model model) { 
  	model.addAttribute("student", new Student());
	      return "views/adminstudentlogin"; 
	     
	  }
	  @RequestMapping(value= "/studentSave", method=RequestMethod.POST)
	  public ModelAndView studentRegistrationSave(@Valid Student student, BindingResult bindingResult)
	  { 
		  ModelAndView model = new ModelAndView();
		  Student userExists =studentService.findStudentByEmail(student.getEmail());
		 
		  if(userExists != null) {
	  
			  bindingResult.rejectValue("email", "error.student","This email already exists!"); 
			  model.addObject("msg", "User has been  already  registered!");
			  model.setViewName("views/adminstudentlogin"); 
			  }
	  
		  if(bindingResult.hasErrors())
		  {
			  model.setViewName("views/adminstudentlogin"); 
		  }
		  else 
		  { 
			  	student.setPassword(new BCryptPasswordEncoder().encode(student.getPassword()));
			  	student.setEnabled(true);
			  	studentService.save(student);
			  	User user=studentService.findStudentByEmail(student.getEmail());
		          UserRole userRole=new UserRole();
		          userRole.setRole("ROLE_STUDENT");
		          userRole.setUser(user);
		          userRoleService.save(userRole);
		          StudentResult studentResult=new StudentResult();
		          studentResult.setStatus(false);
		          studentResult.setStudent(student); 
		          studentResultService.save(studentResult);
			  	model.addObject("msg", "User has been registered successfully!"); 
			  	model.addObject("student", new Student()); 
			    
			  	model.setViewName("views/adminstudentlogin"); 
			  	}
	  
	  return model; 
	  }
	  
	  
	  
	  //Faculty registration----------------------------------------------------------
	  @GetMapping(value = "/facultyaddlogin") 
	  public String facultylogin(Model model) { 
  	model.addAttribute("faculty", new Faculty());
	      return "views/adminfacultylogin"; 
	     
	  }
	  @RequestMapping(value= "/facultySave", method=RequestMethod.POST)
	  public ModelAndView facultyRegistrationSave(@Valid Faculty faculty, BindingResult bindingResult)
	  { 
		  ModelAndView model = new ModelAndView();
		 Faculty userExists =facultyService.findFacultyByEmail(faculty.getEmail());
		 
		  if(userExists != null) {
	  
			  bindingResult.rejectValue("email", "error.student","This email already exists!"); 
			  model.addObject("msg", "User has been  already  registered!");
			  model.setViewName("views/adminfacultylogin"); 
			  }
	  
		  if(bindingResult.hasErrors())
		  {
			  model.setViewName("views/adminfacultylogin"); 
		  }
		  else 
		  { 
			  	faculty.setPassword(new BCryptPasswordEncoder().encode(faculty.getPassword()));
			  	faculty.setEnabled(true);
			  	facultyService.save(faculty);
			  	User user=facultyService.findFacultyByEmail(faculty.getEmail());
		          UserRole userRole=new UserRole();
		          userRole.setRole("ROLE_FACULTY");
		          userRole.setUser(user);
		          userRoleService.save(userRole);
		         
			  	model.addObject("msg", "User has been registered successfully!"); 
			  	model.addObject("faculty", new Faculty()); 
			    
			  	model.setViewName("views/adminfacultylogin"); 
			  	}
	  
	  return model; 
	  }
  
    //Student Result Update----------------------------------------------------------------------------------------
	
	 	
	 	
	 	
		  @RequestMapping("/studentView") public String viewAllStudent(Model model)
		  {
			  List<Student> listdata=studentService.listAll();
		  
		 List<StudentResult> studentResult = studentResultService.listResultAll();
		 
		 
		 model.addAttribute("listdata", listdata);
		 model.addAttribute("studentResult", studentResult);
		  
		  return "views/adminStudentResult"; }
		  
		  
		  @RequestMapping("/editStudent/{email}")
			 public ModelAndView showEditStudent(@PathVariable(name = "email")String email) {
			     ModelAndView mav = new ModelAndView("views/adminstudentResultEdit");
			     StudentResult studentResult = studentResultService.findByStudent(email);
			     mav.addObject("studentResult",  studentResult);
			      
			     return mav;
			 }
		 	 @RequestMapping(value = "/saveStudent", method = RequestMethod.POST)
			 public String saveStudentResult(@ModelAttribute("studentResult") StudentResult studentResult) {
		 		userService.save(studentResult.getStudent());
		 		studentService.save(studentResult.getStudent());
		 		studentResultService.save(studentResult);
		 		
		 		
			     return "redirect:/studentView";
			 }
		 

}

	

