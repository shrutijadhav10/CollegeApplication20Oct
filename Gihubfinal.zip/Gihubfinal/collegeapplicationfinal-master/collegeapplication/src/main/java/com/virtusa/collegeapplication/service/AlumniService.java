package com.virtusa.collegeapplication.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;

import com.virtusa.collegeapplication.models.Alumni;
import com.virtusa.collegeapplication.models.Applicant;
import com.virtusa.collegeapplication.repository.AlumniRepository;



@Service

public class AlumniService {

	
	@Autowired
	private AlumniRepository alumniRepository;
	
	public void save(Alumni alumni) {
		alumniRepository.save(alumni);
    }
    
  
    public Alumni findAlumniByEmail(String email) {
     return alumniRepository.findByEmail(email);
    }
    
    
   
    

    public List<Alumni> getAlumniInfoByPassoutYear(int passoutYear) {
    	List<Alumni> al=alumniRepository.getAlumniInfoByPassoutYear(passoutYear);
    	System.out.println(al.size());
		return al;
	}
   
}
