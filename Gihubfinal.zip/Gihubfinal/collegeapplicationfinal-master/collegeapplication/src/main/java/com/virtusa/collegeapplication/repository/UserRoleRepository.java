package com.virtusa.collegeapplication.repository;

  import java.util.List;
  
  import org.springframework.data.jpa.repository.JpaRepository; 
  import   org.springframework.data.jpa.repository.Query; 
  import   org.springframework.data.repository.query.Param; 
  import   org.springframework.transaction.annotation.Transactional;

import com.virtusa.collegeapplication.models.UserRole;
  

  
  @Transactional 
  public interface UserRoleRepository extends JpaRepository<UserRole,String>{ 
	  //custom jpa method
  
  @Query("SELECT ur FROM UserRole ur WHERE ur.user.email = :email")
  List<UserRole> getUserRolesByName(@Param("email") String email);
  
  }
 