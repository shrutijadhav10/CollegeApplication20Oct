package com.virtusa.collegeapplication.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.virtusa.collegeapplication.models.Alumni;



public interface AlumniRepository extends JpaRepository<Alumni, String>{

	Alumni findByEmail(String email);
	
	@Query("SELECT a FROM Alumni a WHERE a.passoutYear=:passoutYear")
	List<Alumni> getAlumniInfoByPassoutYear(@Param("passoutYear") int passoutYear);
	 
	
}
