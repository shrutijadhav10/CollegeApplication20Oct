package com.virtusa.collegeapplication.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.collegeapplication.models.FacultyTimeTable;

public interface FacultyTimeTableRepository extends JpaRepository<FacultyTimeTable, Long>{

}
