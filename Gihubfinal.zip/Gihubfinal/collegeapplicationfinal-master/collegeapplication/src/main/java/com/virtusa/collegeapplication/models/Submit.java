
  package com.virtusa.collegeapplication.models;
  
  import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId; import
  javax.persistence.OneToOne; import javax.persistence.PrimaryKeyJoinColumn;
  import javax.persistence.Table;
  
  @Entity
  
  @Table(name = "Submit")
 public class Submit  {
  
	  @Id
	  @GeneratedValue(strategy=GenerationType.AUTO)
	  
	  @Column(name="Id") 
	  private Long id;
	  
	  @Column(name="Department") 
	  @Enumerated(EnumType.STRING)
	  private Department department;
	  
	  @Column(name="Year") 
	  @Enumerated(EnumType.STRING)
	  private Year year;
	  
	  @Column(name="Division") 
	
	  private String division;
	  
	  @Lob
	  @Column(name="Pdf")
	  private byte[] pdf;
	  
	  @ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.LAZY) 
	  private Student student;
	  
	  
	  @ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.LAZY) 
	  private Assignment assignment;


	public Submit(byte[] pdf) {
		// TODO Auto-generated constructor stub
		this.pdf=pdf;
	}


	public Submit(byte[] pdf, Assignment assignment) {
		// TODO Auto-generated constructor stub
		this.pdf = pdf;
		this.assignment = assignment;
	}


	public Submit(byte[] pdf,  Assignment assignment,Student student, Department department, Year year, String division) {
		// TODO Auto-generated constructor stub
		this.pdf = pdf;
		this.assignment = assignment;
		this.department = department;
		this.year = year;
		this.division = division;
		this.student=student;
	}


	public Submit() {
		// TODO Auto-generated constructor stub
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public Department getDepartment() {
		return department;
	}


	public void setDepartment(Department department) {
		this.department = department;
	}


	public Year getYear() {
		return year;
	}


	public void setYear(Year year) {
		this.year = year;
	}


	public String getDivision() {
		return division;
	}


	public void setDivision(String division) {
		this.division = division;
	}


	public byte[] getPdf() {
		return pdf;
	}


	public void setPdf(byte[] pdf) {
		this.pdf = pdf;
	}


	public Student getStudent() {
		return student;
	}


	public void setStudent(Student student) {
		this.student = student;
	}


	public Assignment getAssignment() {
		return assignment;
	}


	public void setAssignment(Assignment assignment) {
		this.assignment = assignment;
	}
	  
	  
  
  }
 