package com.virtusa.collegeapplication.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.collegeapplication.models.FacultyTimeTable;
import com.virtusa.collegeapplication.models.StudentTimeTable;
import com.virtusa.collegeapplication.repository.FacultyTimeTableRepository;

@Service
public class FacultyTimeTableService {
	@Autowired
    private FacultyTimeTableRepository facultyTimeTableRepository;
	
	private static final Logger logger = LoggerFactory.getLogger("FacultyTimeTable.class");
	
	 public List<FacultyTimeTable> listAll() {
	        return facultyTimeTableRepository.findAll();
	    }
		  public FacultyTimeTable getFile(long id) {
		        return facultyTimeTableRepository.findById(id)
		        		.orElseThrow(() -> new MyFileNotFoundException("File not found with id " + id));
		    }
		  
		  

		    public int savePdf(FacultyTimeTable model) {
		        try {
		        	facultyTimeTableRepository.save(model);
		            return 1;
		        } catch (Exception e) {
		            logger.error("ERROR", e);
		            return 0;
		        }
		    }
}
