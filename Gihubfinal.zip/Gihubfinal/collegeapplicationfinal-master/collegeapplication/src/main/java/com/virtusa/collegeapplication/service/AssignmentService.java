package com.virtusa.collegeapplication.service;

import java.util.List;

/*import org.slf4j.Logger;
import org.slf4j.LoggerFactory;*/
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.collegeapplication.CollegeapplicationApplication;
import com.virtusa.collegeapplication.models.Assignment;
import com.virtusa.collegeapplication.models.Submit;
import com.virtusa.collegeapplication.models.UniversityTimeTable;
import com.virtusa.collegeapplication.repository.AssignmentRepository;

@Service
public class AssignmentService {
	
	 private static Logger logger = (Logger) LogManager.getLogger(AssignmentService.class) ;
	@Autowired
    private AssignmentRepository assignmentRepository;
	 public List<Assignment> listAll() {
	        return assignmentRepository.findAll();
	    }
		  public Assignment getFile(long id) {
		        return assignmentRepository.findById(id)
		        		.orElseThrow(() -> new MyFileNotFoundException("File not found with id " + id));
		    }
		  
		  
		  public int saveImage(Assignment model) {
		        try {
		        	assignmentRepository.save(model);
		            return 1;
		        } catch (Exception e) {
		            logger.error("ERROR", e);
		            return 0;
		        }
		    }

}
