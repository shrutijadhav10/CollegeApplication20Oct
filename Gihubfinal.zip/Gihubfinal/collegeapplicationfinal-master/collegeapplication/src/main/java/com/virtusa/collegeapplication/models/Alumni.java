package com.virtusa.collegeapplication.models;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

@Entity
@Table(name = "Alumni")
@PrimaryKeyJoinColumn
public class Alumni extends User{
	
	
	
	
	
		@Column(name="FirstName")
		private String firstName;
		@Column(name="LastName")
		private String lastName;
		@Column(name="Address")
		private String address;
		@Column(name="PhoneNo")
		private Long phoneNo;
		@Column(name="Gender")
		private String gender;
		@Column(name="Birthdate")
		@DateTimeFormat(iso = ISO.DATE)
		private LocalDate birthdate;
		@Column(name="Department")
		@Enumerated(EnumType.STRING)
		private Department department;
		@Column(name="PassoutYear")
		private int passoutYear;
		@Column(name="EmployeeType")
		private String employeeType;
		@Column(name="Designation")
		private String designation;
		@Column(name="CompanyOrganisationName")
		private String companyName;
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public Long getPhoneNo() {
			return phoneNo;
		}
		public void setPhoneNo(Long phoneNo) {
			this.phoneNo = phoneNo;
		}
		public String getGender() {
			return gender;
		}
		public void setGender(String gender) {
			this.gender = gender;
		}
		public LocalDate getBirthdate() {
			return birthdate;
		}
		public void setBirthdate(LocalDate birthdate) {
			this.birthdate = birthdate;
		}
		public Department getDepartment() {
			return department;
		}
		public void setDepartment(Department department) {
			this.department = department;
		}
		public int getPassoutYear() {
			return passoutYear;
		}
		public void setPassoutYear(int passoutYear) {
			this.passoutYear = passoutYear;
		}
		public String getEmployeeType() {
			return employeeType;
		}
		public void setEmployeeType(String employeeType) {
			this.employeeType = employeeType;
		}
		public String getDesignation() {
			return designation;
		}
		public void setDesignation(String designation) {
			this.designation = designation;
		}
		public String getCompanyName() {
			return companyName;
		}
		public void setCompanyName(String companyName) {
			this.companyName = companyName;
		}
		
		
		
		
		
		
}
