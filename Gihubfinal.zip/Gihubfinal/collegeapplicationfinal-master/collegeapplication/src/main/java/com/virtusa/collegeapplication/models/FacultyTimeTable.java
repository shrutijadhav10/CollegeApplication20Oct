
  package com.virtusa.collegeapplication.models;
  
  import javax.persistence.Column; import javax.persistence.DiscriminatorValue;
  import javax.persistence.Entity; import javax.persistence.GeneratedValue;
  import javax.persistence.GenerationType; import javax.persistence.Id; import
  javax.persistence.Lob; import javax.persistence.SequenceGenerator; import
  javax.persistence.Table;
  
  @Entity
  @Table(name ="FacultyTimeTable") 
  public class FacultyTimeTable extends TimeTable {
  
  
 


public FacultyTimeTable(String timetableType, Department department, Semester semester, Year year, String division,
		byte[] pdf) {
	// TODO Auto-generated constructor stub
	super(timetableType, department, semester, year, division);
	this.pdf = pdf;
}

@Lob
  @Column(name="Pdf") 
  private byte[] pdf;

public byte[] getPdf() {
	return pdf;
}

public void setPdf(byte[] pdf) {
	this.pdf = pdf;
}
  
public FacultyTimeTable()
{
	super();
}
 
  
  }
 