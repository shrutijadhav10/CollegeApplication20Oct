package com.virtusa.collegeapplication.controllers;

import java.util.Arrays;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.virtusa.collegeapplication.models.Alumni;
import com.virtusa.collegeapplication.models.Applicant;
import com.virtusa.collegeapplication.models.ApplicantResult;
import com.virtusa.collegeapplication.models.Course;
import com.virtusa.collegeapplication.models.Department;
import com.virtusa.collegeapplication.models.Semester;
import com.virtusa.collegeapplication.models.Student;
import com.virtusa.collegeapplication.models.StudentResult;
import com.virtusa.collegeapplication.models.Year;
import com.virtusa.collegeapplication.service.StudentResultService;
import com.virtusa.collegeapplication.service.StudentService;

@Controller 
public class StudentController {

	@Autowired
	private StudentService studentService;
	 @Autowired
	    private StudentResultService studentResultService;

   @Autowired
   HttpSession httpSession;
	
   
   
   
 //Show the Student Profile-----------------------------------------------------------------------------------------------------  
	 @RequestMapping("/studentProfile")
	 public ModelAndView showEditProductPage() {
		 
		 System.out.println(httpSession.getAttribute("studentEmail"));
	     ModelAndView mav = new ModelAndView("views/student_profile");
	     mav.addObject("departments",Arrays.asList(Department.values()));
	     mav.addObject("courses",Arrays.asList(Course.values()));
	     mav.addObject("years",Arrays.asList(Year.values()));
	     mav.addObject("semesters",Arrays.asList(Semester.values()));
	     Student student = studentService .findStudentByEmail(httpSession.getAttribute("studentEmail").toString());
	     mav.addObject("student",student);
	      
	     return mav;
	 }
	  
	//Update the Student Profile------------------------------------------------------------------------------------
	  @RequestMapping(value = "/studentUpdate", method = RequestMethod.POST) public
	  String saveProduct(@ModelAttribute("student") Student student,RedirectAttributes redirAttrs)
	  {
		  redirAttrs.addFlashAttribute("message", "User has been Updated Record successfully!");

//System.out.println(student.getPassword());
		  student.setPassword(student.getPassword());
		  student.setEnabled(true);
		  String email=student.getEmail();
	 studentService.save(student); 
	  return "redirect:/studentProfile/"; 
	  }
	  
	  
	  
	//View the Student Result After Login------------------------------------------------------------------------------- 
 	  @RequestMapping("/studentResultStatus") 
	  public ModelAndView viewStudentResultStatus(Model model) 
	  {
		  ModelAndView mav = new ModelAndView("views/studentResultStatus");
		  String email=httpSession.getAttribute("studentEmail").toString();
		  System.out.println("Student Result:"+email);
		  StudentResult studentResult =studentResultService.findByStudent(email);
		  mav.addObject("student",studentResult);
		  
		  
		  return mav; 
		  
	  }
	  
	  
	  
	
}
