$(document).ready(function () {

    $("#search-form").submit(function (event) {

        //stop submit the form, we will post it manually.
        event.preventDefault();

        fire_ajax_submit();

    });

});

function fire_ajax_submit() {

    var passoutYear = $("#passoutYear").val();
    
    $("#btn-search").prop("disabled", true);

    var alumni={
    		"passoutYear":passoutYear
    }
    $.ajax({
        type: "POST",
        contentType: "application/json",
        url: "/doAlumniSearch",
        data: JSON.stringify(alumni),
        dataType: 'json',
        cache: false,
        timeout: 600000,
        success: function (data) {

        	data.forEach(function(dt){
        		$('table').append("<tr><td>"+dt.email+"</td><td>"+dt.phoneNo+"</td></tr>");
        	});
        	
//          
//        	$("#feedback tr").remove();
//        	var $tr = $('<tr>');
//        	 $.each(data, function(i, item) {
//        		
//        		 $tr.append(
//        	            $('<td>').text(item)
//        	        ); //.appendTo('#records_table');
//        		 console.log(item);
//        	       
//        	    });
//        	 $('#feedback').append($tr);
//        	 
//            $("#btn-search").prop("disabled", false);

        },
        error: function (e) {

            var json = "<h4>Ajax Response</h4><pre>"
                + e.responseText + "</pre>";
            $('#feedback').html(json);

            console.log("ERROR : ", e);
            $("#btn-search").prop("disabled", false);

        }
    });

}